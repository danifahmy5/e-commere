<?php

	$pesanan_id= $_GET["pesanan_id"];

	$query = mysqli_query($koneksi, "SELECT pesanan.nama_penerima, pesanan.nomor_telepon, pesanan.alamat, pesanan.tanggal_pemesanan, user.nama FROM pesanan JOIN user ON pesanan.user_id=user.user_id WHERE pesanan.pesanan_id='$pesanan_id'");

	$row=mysqli_fetch_assoc($query);

	$tanggal_pemesanan = $row['tanggal_pemesanan'];
	$nama_penerima = $row['nama_penerima'];
	$nomor_telepon = $row['nomor_telepon'];
	$alamat = $row['alamat'];
	$nama = $row['nama'];

?>

<div class="frame-faktur">
	<h3 class="detail-pengiriman text-center">Detail Pesanan</h3>
	<hr/>
	<table>	
		<tr>
			<td>Nomor Faktur</td>
			<td>:</td>
			<td><?php echo $pesanan_id; ?></td>
		</tr>
		<tr>
			<td>Nama Pemesan</td>
			<td>:</td>
			<td><?php echo $nama; ?></td>
		</tr>
		<tr>
			<td>Nama Penerima</td>
			<td>:</td>
			<td><?php echo $nama_penerima; ?></td>
		</tr>
		<tr>
			<td>Alamat</td>
			<td>:</td>
			<td><?php echo $alamat; ?></td>
		</tr>
		<tr>
			<td>Nomor Telepon</td>
			<td>:</td>
			<td><?php echo $nomor_telepon; ?></td>
		</tr>
		<tr>
			<td>Tanggal Pemesanan</td>
			<td>:</td>
			<td><?php echo $tanggal_pemesanan; ?></td>
		</tr>
	</table>
</div>
<div class="table-responsive jumlah">
	<table class="table">
		<thead class="table thead-dark">
		<tr>
			<th scope="col">No</th>
			<th scope="col">Nama Barang</th>
			<th scope="col">Qty</th>
			<th scope="col">Harga Satuan</th>
			<th scope="col">Total</th>
		</tr>
		</thead>
		<?php

			$queryDetail = mysqli_query($koneksi, "SELECT pesanan_detail.*, barang.nama_barang FROM pesanan_detail JOIN barang ON pesanan_detail.barang_id=barang.barang_id WHERE pesanan_detail.pesanan_id='$pesanan_id'");

			$no = 1;
			$subtotal = 0;
			while ($rowDetail=mysqli_fetch_assoc($queryDetail)) {
				
				$total = $rowDetail["harga"] * $rowDetail["quantity"];
				$subtotal = $subtotal + $total;

				echo "<tr>
						<td class='no'>$no</td>
						<td class='kiri'>$rowDetail[nama_barang]</td>
						<td class='tengah'>$rowDetail[quantity]</td>
						<td class='kanan'>".rupiah($rowDetail['harga'])."</td>
						<td class='kanan'>".rupiah($total)."</td>
					</tr>";

				$no++;
			}
		?>
		<tr>
			<td class="kanan" colspan="4"><b>Sub total</b></td>
			<td class="kanan"><b><?php echo rupiah($subtotal); ?></b></td>
		</tr>		
	</table>
	<b>Silakan lakukan transaksi via wa di bawah sini</b><br>
	<div class="btn-group" role="group">
		   <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=6285700006909&text=Halo%20Admin%20saya%20mau%20order">
		   	<img src="<?php echo BASE_URL."images/wa.png"?>">
		   </a>
		   <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=6285700006909&text=Halo%20Admin%20saya%20mau%20order">whatsapp</a>		
	</div>
</div>
	