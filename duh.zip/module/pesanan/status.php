<?php

	$pesanan_id = $_GET["pesanan_id"];

	$query = mysqli_query($koneksi, "SELECT status FROM pesanan WHERE pesanan_id='$pesanan_id'");
	$row=mysqli_fetch_assoc($query);
	$status = $row['status'];

?>
<form action="<?php echo BASE_URL."module/pesanan/action.php?pesanan_id=$pesanan_id"; ?>" method="POST">

	<div class="form-group">
		<label>Pesanan Id (Faktur Id)</label>
		<span><input class="form-control" type="text" value="<?php echo $pesanan_id; ?>" name="Pesanan_id" readonly="true" /></span>
	</div>

	<div class="form-group">
		<label>Status</label>
		<span>
			<select class="form-control" name="status">
				<?php

					foreach ($arrayStatusPesanan as $key => $value) {
						if ($status == $key) {
							echo "<option value='$key' selected='true'>$value</option>";
						}else{
							echo "<option value='$key'>$value</option>";
						}
						
					}
				?>
			</select>
		</span>
	</div>

	<div class="form-actions form-group">
		<span><input class="btn btn-primary btn-sm" type="submit" value="Edit Status" name="button"></span>
	</div>
	
</form>