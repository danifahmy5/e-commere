<?php


     $server = "localhost:8080";
     $username = "root";
     $password = "";
     $database = "xxxxxxx";


     $koneksi = mysqli_connect($server, $username, $password, $database) or die("koneksi ke database gagal");