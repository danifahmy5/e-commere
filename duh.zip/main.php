<div class="animated fadeIn">
<div class="row">	
		<?php

			if($kategori_id) {
				$kategori_id = "AND barang.kategori_id='$kategori_id'";
			}

			$pegination = isset($_GET["pegination"]) ? $_GET["pegination"] : 1;
		    $data_perhalaman = 12;
		    $mulai_dari = ($pegination-1) * $data_perhalaman;

			$query = mysqli_query($koneksi, "SELECT barang.*, kategori.kategori FROM barang JOIN kategori ON barang.kategori_id=kategori.kategori_id WHERE barang.status='on' $kategori_id ORDER BY rand() DESC LIMIT $mulai_dari, $data_perhalaman" );

			$no=1;
			
			
			while($row=mysqli_fetch_assoc($query)) {

				$kategori = strtolower($row["kategori"]);
				$barang = strtolower($row["nama_barang"]);
				$barang = str_replace(" ", "-", $barang);
						
				echo "<div class='col-sm-6 col-lg-3 bg-white p-3 border'>
						<div class='card>
						<div class='card-body'>

						
							<div class='gambar-produk '>
								<a href='".BASE_URL."index.php?page=detail&barang_id=$row[barang_id]'>
									<img src='".BASE_URL."images/barang/$row[gambar]' class='img-thumbnail'>
								</a>
								</div>
								<div class='keterangan-gambar'>
									<p class='nama text-center'>
										<a href='".BASE_URL."$row[barang_id]/$kategori/$barang.html'>$row[nama_barang]</a>
									</p>
								<p class='price'>".rupiah($row['harga'])."</p>
								</div>
								<div class='button-add-cart'>
									<a href='".BASE_URL."tambah_keranjang.php?barang_id=$row[barang_id]'>
										<img class='mr-2 mb-1' src='".BASE_URL."images/cart.png'> 
										Masukan keranjang
									</a>
								</div>
							
							</div>
						</div>";
						
			}
		?>
</div>
</div>
<?php 
		if ($kategori_id == 0) {
		
			$queryHitungKategori = mysqli_query($koneksi, "SELECT * FROM barang");
		    $total_data = mysqli_num_rows($queryHitungKategori);
		    $total_halaman = ceil($total_data / $data_perhalaman);

		    $batasPosisiNomor = 6;
		    $batasJumlahHalaman = 10;
		    $mulaiPegination = 1;
		    $batasAkhirPegination = $total_halaman;

		     echo "<nav>
		     		<ul class='pagination'>";

		     	if ($pegination > 1) {
				     	$pref = $pegination - 1;
				     	echo "<li class='page-item'>
				     			<a href='".BASE_URL."index.php?pegination=$pref'>
				     				<span class='page-link'>Previous</span>
				     			</a>
				     		  </li>";
				     }

		         for ($i=1; $i <= $total_halaman; $i++) { 
		            if ($pegination == $i) {
		              echo "<li class='page-item active'>
		              			<a class='page-link' href='".BASE_URL."index.php?pegination=$i'>$i
		              			</a>
		              		</li>";
		            }else{
		               echo "<li class='page-item'>
		               			<a class='page-link' href='".BASE_URL."index.php?pegination=$i'>$i</a>
		               		</li>";
		            }
		         }
		         if ($pegination < $total_halaman) {
		     			$next = $pegination + 1;
		     			echo "<li><a class='page-link' href='".BASE_URL."index.php?pegination=$next'> next</a></li>";
		     		}
		     echo "</ul>
		     	   </nav>";
		}
	 ?>