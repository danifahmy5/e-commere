<?php
   
    if($user_id){
    	header("location: ".BASE_URL );
    }
?>
<div class="container-login">    
	<div class="card px-3 py-3">
		<div class="card-body">


			<form class="px-3 py-3 col-md-4 mx-auto my-auto bg-light" action="<?php echo BASE_URL."proses_login.php"; ?>" method="POST">
				<?php
				
				     $notif = isset($_GET['notif']) ? $_GET['notif'] : false;

				     if ($notif == true) {
				     	echo "<div class='notif'>Maaf, email atau password yang anda masukan tidak cocok</div>";
				     	}
				 ?>

						
				<div class="form-group">
					<label>Email</label>
					<span><input type="email" name="email" class="form-control" placeholder="masukan email"></span>
					
				</div>

				<div class="form-group">
					<label>Password</label>
					<span><input type="password" name="password" class="form-control" placeholder="masukkan password"></span>
					
				</div>

				<div class="element-from">
					<span><input class="btn btn-primary" type="submit" value="login" /></span>
					
				</div>
			</form>
		</div>
	</div>
</div>